//
//  StorageButtonView.swift
//  AppleStore
//
//  Created by SIKim on 2023/09/06.
//

import SwiftUI

struct StorageButtonView: View {
    @Binding var isCheckButton: Bool
    var body: some View {
        VStack {
            Group {
                Text("용량(128GB²)")
                    .foregroundColor(.black)
                    .padding([.top], 25.0)
                Text("기격(₩1,250,000)")
                    .foregroundColor(.gray)
                    .padding([.bottom], 25.0)
            }
            .font(.footnote)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .overlay(
            RoundedRectangle(cornerRadius: 5)
                .stroke(isCheckButton ? Color.blue : Color(.systemGray3),
                        lineWidth:
                            isCheckButton ? 3 : 1
                    )
        )
    }
}

struct StorageButtonView_Previews: PreviewProvider {
    static var previews: some View {
        StorageButtonView(isCheckButton: .constant(true))
    }
}
