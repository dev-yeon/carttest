//
//  StoragePickView.swift
//  AppleStore
//
//  Created by SIKim on 2023/09/06.
//

import SwiftUI

struct StoragePickView: View {
    @State private var title: String = "용량이 얼마나 필요할지 확실치 않으신가요?"
    @State private var description: String = "자신에게 어느 정도의 저장 용량이 필요할지 감 잡아보기."
    
    @State var isCheckStorage0: Bool = false
    @State var isCheckStorage1: Bool = false
    @State var isCheckStorage2: Bool = false
    private var isCheckButtonActive: Bool {
        isCheckStorage0 || isCheckStorage1 || isCheckStorage2 ? false : true
    }
    var body: some View {
        VStack {
            HStack {
                Text("저장 용량.")
                    .fontWeight(.bold)
                Text("당신에게 알맞은 저장 용량은?")
                Spacer()
            }
            .padding()
            .font(.title2)
            Grid {
                GridRow {
                    Button {
                        isCheckStorage0 = true
                        isCheckStorage1 = isCheckButtonActive
                        isCheckStorage2 = isCheckButtonActive
                    } label: {
                        StorageButtonView(isCheckButton: $isCheckStorage0)
                    }
                    .padding([.leading])
                    
                    Button {
                        isCheckStorage1 = true
                        isCheckStorage0 = isCheckButtonActive
                        isCheckStorage2 = isCheckButtonActive
                    } label: {
                        StorageButtonView(isCheckButton: $isCheckStorage1)
                    }
                    .padding([.trailing])
                }
                
                GridRow {
                    Button {
                        isCheckStorage2 = true
                        isCheckStorage1 = isCheckButtonActive
                        isCheckStorage0 = isCheckButtonActive
                    } label: {
                        StorageButtonView(isCheckButton: $isCheckStorage2)
                    }
                    .padding([.leading])
                }
            }
            HelpView(title: $title, description: $description)
        }
    }
}

struct StoragePickView_Previews: PreviewProvider {
    static var previews: some View {
        StoragePickView()
    }
}
