//
//  ColorButtonView.swift
//  AppleStore
//
//  Created by SIKim on 2023/09/06.
//

import SwiftUI

struct ColorButtonView: View {
    @Binding var isCheckButton: Bool
    
    var body: some View {
        VStack {
            Group {
                Circle()
                    .fill(.indigo)
                    .frame(width: 20, height: 20)
                    .padding([.top], 25.0)
                Text("색상")
                    .font(.footnote)
                    .foregroundColor(.black)
                    .padding([.bottom], 25.0)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .overlay(
            RoundedRectangle(cornerRadius: 5)
                .stroke(isCheckButton ? Color.blue : Color(.systemGray3),
                        lineWidth:
                            isCheckButton ? 3 : 1
                    )
        )
    }
}

struct ColorButtonView_Previews: PreviewProvider {
    static var previews: some View {
        ColorButtonView(isCheckButton: .constant(true))
    }
}
