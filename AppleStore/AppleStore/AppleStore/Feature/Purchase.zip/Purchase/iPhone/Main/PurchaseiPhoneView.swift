//
//  PurchaseiPhoneView.swift
//  AppleStore
//
//  Created by SIKim on 2023/09/05.
//

import SwiftUI

struct PurchaseiPhoneView: View {
    @State private var isShowingShare: Bool = false
    @State private var isShowingBookmark: Bool = false
    
    var body: some View {
        NavigationStack {
            VStack {
                Text("가격(ex: ₩1,250,000)")
                    .font(.footnote)
                    .frame(width: 400, height: 45)
                    .border(Color(.systemGray5))
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        isShowingShare.toggle()
                    } label: {
                        Image(systemName: "square.and.arrow.up")
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        
                    } label: {
                        Image(systemName: "bookmark")
                    }
                    .disabled(true)
                }
            }
            .sheet(isPresented: $isShowingShare) {
                Text("공유하기 준비중")
                    .presentationDetents([.medium, .large])
            }
            .sheet(isPresented: $isShowingBookmark) {
                Text("관심제품 준비중")
                    .presentationDetents([.medium, .large])
            }
            ScrollView {
                Text("Event Text(ex: iPhone과 함께 누리는 Apple Music 6개월 무료 혜택.)")
                    .padding()
                    .font(.caption2)
                
                iPhoneProductView()
                
                ModelPickView()
                
                ColorPickView()
                //                    .opacity(0.5)
                //                    .disabled(true)
                
                StoragePickView()
                
                ProductContentsView()
                
                Divider()
                
                DeliveryGuideView()
            }
        }
    }
}

struct PurchaseiPhoneView_Previews: PreviewProvider {
    static var previews: some View {
            PurchaseiPhoneView()
    }
}
  
//struct iPhoneSeries {
//    var seriesNames: String //아이폰 시리즈 이름 예: iPhone 14
//    var productNames: [String]  //아이폰 시리즈 내의 제품들 예: iPhone 14, 14Plus
//    var prices: [String]    //제품들 옵션에 따른 가격들, Int로 쓸지 String으로 쓸지 체크
//    var mainImageStrings: [String]  //구매페이지에서 먼저 보이는 이미지들, 옵션 선택마다 이미지가 바뀌어서 배열로 일단 뒀음
//    var galleryStrings: [String]    //갤러리 버튼 누르면 이미지 여러장나옴
//    var productColors: [String] //시리즈에 따른 색상들
//    var storages: [String]  //저장용량들, Int로 할지 String으로 할지 체크
//    var contentsImageStrings: [String]  //제품구성에 들어갈 이미지들
//}
//
//struct iPad {
//    var productName: String //제품 이름
//    var prices: [String]    //옵션에 따른 가격들, Int로 쓸지 String으로 쓸지 체크
//    var inchModels: [String]    //제품에 따른 인치 옵션들
//    var mainImageStrings: [String]  //구매 페이지에서 먼저 보이는 이미지들, 옵션선택에 따라 이미지가 바뀌어서 배열로 둠
//    var galleryStrings: [String]    //갤러리 버튼 누르면 이미지 여러장나옴
//    var productColors: [String] //제품의 색상들
//    var storages: [String]  //저장용량들, Int로 할지 String으로 할지 체크
//    var EmbedCellular: [String]   //wifi / wifi + cellular
//}
