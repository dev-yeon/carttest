//
//  iPhoneProductView.swift
//  AppleStore
//
//  Created by SIKim on 2023/09/05.
//

import SwiftUI

struct iPhoneProductView: View {
    @State private var isNewProduct: Bool = true
    @State private var isShowingMoreInfo: Bool = false
    @State private var isShowingGallery: Bool = false
    
    var body: some View {
        //        VStack {
        VStack {
            Text(isNewProduct ? "New" : "")
                .padding(4)
                .font(.caption2)
                .foregroundColor(.orange)
            Text("Title(ex: iPhone 14 구입하기)")
                .font(.title)
                .fontWeight(.bold)
            AsyncImage(url: URL(string: "https://store.storeimages.cdn-apple.com/8756/as-images.apple.com/is/iphone-card-40-iphone14-202209?wid=340&hei=264&fmt=p-jpg&qlt=95&.v=1661958160674")) { image in
                image
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            } placeholder: {
                Image(systemName: "xmark.app")
            }
            .padding()
        }
        .padding()
//                    .border(Color(.systemGray5))
        Divider()
        
        HStack(alignment: .top) {
            Button {
                isShowingMoreInfo.toggle()
            } label: {
                Text("더 알아보기")
                    .font(.footnote)
                    .padding()
                    .frame(maxWidth: .infinity)
//                                            .border(Color(.systemGray5))
            }
            
            Divider()
            
            Button {
                isShowingGallery.toggle()
            } label: {
                Text("갤러리")
                    .font(.footnote)
                    .padding()
                    .frame(maxWidth: .infinity)
//                                        .border(Color(.systemGray5))
            }
        }
        .fullScreenCover(isPresented: $isShowingMoreInfo, content: {
            NavigationStack {
                Text("더 알아보기 준비중")
                    .toolbar {
                        ToolbarItem(placement: .navigationBarTrailing) {
                            Button {
                                isShowingMoreInfo.toggle()
                            } label: {
                                Image(systemName: "xmark.circle.fill")
                                    .foregroundColor(.black)
                            }
                        }
                    }
            }
        })
        .sheet(isPresented: $isShowingGallery) {
            Text("갤러리 준비중")
        }
        Divider()
        //        }
    }
}

struct iPhoneProductView_Previews: PreviewProvider {
    static var previews: some View {
        VStack {
            iPhoneProductView()
        }
    }
}
