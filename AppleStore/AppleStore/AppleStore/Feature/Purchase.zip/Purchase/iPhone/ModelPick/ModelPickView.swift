//
//  ModelPickView.swift
//  AppleStore
//
//  Created by SIKim on 2023/09/05.
//

import SwiftUI

struct ModelPickView: View {
    @State private var title: String = "모델 선택에 도움이 필요하신가요?"
    @State private var description: String = "화면 크기와 배터리 사용 시간 등 차이점을 비교해보세요."
    
    @State var isCheckNormalButton: Bool = false
    @State var isCheckProButton: Bool = false
    var body: some View {
        VStack {
            HStack {
                Text("모델.")
                    .fontWeight(.bold)
                Text("당신에게 딱 맞는 모델은?")
                Spacer()
            }
            .padding()
            .font(.title2)
            
            Button {
                isCheckNormalButton = true
                isCheckProButton = !isCheckNormalButton
            } label: {
                ModelButtonView(isCheckButton: $isCheckNormalButton)
            }
            
            Button {
                isCheckProButton = true
                isCheckNormalButton = !isCheckProButton
            } label: {
                ModelButtonView(isCheckButton: $isCheckProButton)
            }
            
            HelpView(title: $title, description: $description)
        }
    }
}

struct ModelPickView_Previews: PreviewProvider {
    static var previews: some View {
            ModelPickView()
    }
}
